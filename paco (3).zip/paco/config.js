// Preencha com os dados do seu projeto no Supabase (veja o LEIA-ME.md).
// Enquanto estiver vazio, o PACO funciona em "modo local": tudo fica salvo só neste aparelho.
window.PACO_CONFIG = window.PACO_CONFIG || {
  url: '',   // exemplo: 'https://abcdefghijkl.supabase.co'
  key: ''    // chave "anon" (ou "publishable") do projeto
};
